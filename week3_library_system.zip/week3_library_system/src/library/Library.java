package library;

import java.util.ArrayList;

public class Library {

    private ArrayList<Book> books;

    private ArrayList<Member> members;

    private FileHandler fileHandler;

    public Library() {

        fileHandler = new FileHandler();

        books = fileHandler.loadBooks();

        members = new ArrayList<>();
    }

    public void addBook(Book book) {

        books.add(book);

        fileHandler.saveBooks(books);

        System.out.println("Book Added Successfully");
    }

    public void viewBooks() {

        if (books.isEmpty()) {

            System.out.println("No Books Available");

            return;
        }

        System.out.println("\n=== BOOK LIST ===");

        for (Book book : books) {

            System.out.println(book);
        }
    }

    public Book searchBook(String isbn) {

        for (Book book : books) {

            if (book.getIsbn().equals(isbn)) {

                return book;
            }
        }

        return null;
    }

    public void removeBook(String isbn) {

        Book book = searchBook(isbn);

        if (book != null) {

            books.remove(book);

            fileHandler.saveBooks(books);

            System.out.println("Book Removed");

        } else {

            System.out.println("Book Not Found");
        }
    }

    public void registerMember(Member member) {

        members.add(member);

        System.out.println("Member Registered");
    }

    public Member searchMember(String id) {

        for (Member member : members) {

            if (member.getId().equals(id)) {

                return member;
            }
        }

        return null;
    }

    public void borrowBook(String isbn, String memberId) {

        Book book = searchBook(isbn);

        Member member = searchMember(memberId);

        if (book == null) {

            System.out.println("Book Not Found");

            return;
        }

        if (member == null) {

            System.out.println("Member Not Found");

            return;
        }

        if (!book.isAvailable()) {

            System.out.println("Book Already Borrowed");

            return;
        }

        book.setAvailable(false);

        book.setBorrowedBy(memberId);

        member.borrowBook(isbn);

        System.out.println("Book Borrowed Successfully");
    }

    public void displayStatistics() {

        int totalBooks = books.size();

        int availableBooks = 0;

        for (Book book : books) {

            if (book.isAvailable()) {

                availableBooks++;
            }
        }

        System.out.println("\n=== LIBRARY STATISTICS ===");

        System.out.println("Total Books: " + totalBooks);

        System.out.println("Available Books: " + availableBooks);

        System.out.println("Borrowed Books: " + (totalBooks - availableBooks));

        System.out.println("Registered Members: " + members.size());
    }
}