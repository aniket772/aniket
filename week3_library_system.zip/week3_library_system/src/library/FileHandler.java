package library;

import java.io.*;
import java.util.ArrayList;

public class FileHandler {

    private final String BOOK_FILE = "data/books.txt";

    private final String MEMBER_FILE = "data/members.txt";

    public void saveBooks(ArrayList<Book> books) {

        try (PrintWriter writer = new PrintWriter(new FileWriter(BOOK_FILE))) {

            for (Book book : books) {

                writer.println(
                        book.getIsbn() + "," +
                        book.getTitle() + "," +
                        book.getAuthor() + "," +
                        book.getYear()
                );
            }

        } catch (IOException e) {

            System.out.println("Error saving books");
        }
    }

    public ArrayList<Book> loadBooks() {

        ArrayList<Book> books = new ArrayList<>();

        File file = new File(BOOK_FILE);

        if (!file.exists()) {
            return books;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {

            String line;

            while ((line = reader.readLine()) != null) {

                String[] data = line.split(",");

                Book book = new Book(
                        data[0],
                        data[1],
                        data[2],
                        Integer.parseInt(data[3])
                );

                books.add(book);
            }

        } catch (IOException e) {

            System.out.println("Error loading books");
        }

        return books;
    }
}