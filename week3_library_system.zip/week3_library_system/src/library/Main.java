package library;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        Library library = new Library();

        while (true) {

            System.out.println("\n=== LIBRARY MANAGEMENT SYSTEM ===");

            System.out.println("1. Add New Book");

            System.out.println("2. View All Books");

            System.out.println("3. Remove Book");

            System.out.println("4. Register Member");

            System.out.println("5. Borrow Book");

            System.out.println("6. View Statistics");

            System.out.println("7. Exit");

            System.out.print("Enter Choice: ");

            int choice = sc.nextInt();

            sc.nextLine();

            switch (choice) {

                case 1:

                    System.out.print("Enter ISBN: ");
                    String isbn = sc.nextLine();

                    System.out.print("Enter Title: ");
                    String title = sc.nextLine();

                    System.out.print("Enter Author: ");
                    String author = sc.nextLine();

                    System.out.print("Enter Year: ");
                    int year = sc.nextInt();

                    library.addBook(
                            new Book(isbn, title, author, year)
                    );

                    break;

                case 2:

                    library.viewBooks();

                    break;

                case 3:

                    System.out.print("Enter ISBN: ");

                    library.removeBook(sc.nextLine());

                    break;

                case 4:

                    System.out.print("Enter Member ID: ");
                    String id = sc.nextLine();

                    System.out.print("Enter Member Name: ");
                    String name = sc.nextLine();

                    library.registerMember(
                            new Member(id, name)
                    );

                    break;

                case 5:

                    System.out.print("Enter ISBN: ");
                    String bookIsbn = sc.nextLine();

                    System.out.print("Enter Member ID: ");
                    String memberId = sc.nextLine();

                    library.borrowBook(bookIsbn, memberId);

                    break;

                case 6:

                    library.displayStatistics();

                    break;

                case 7:

                    System.out.println("Exiting...");

                    System.exit(0);

                default:

                    System.out.println("Invalid Choice");
            }
        }
    }
}