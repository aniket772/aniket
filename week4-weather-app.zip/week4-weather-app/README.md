# Weather Application

## Project Description
A responsive weather dashboard using OpenWeatherMap API.

## Features
- Current Weather
- 5-Day Forecast
- City Search
- Unit Conversion
- Responsive Design
- Local Storage

## Technologies Used
- HTML
- CSS
- JavaScript
- OpenWeatherMap API

## Setup Instructions

1. Download project
2. Add API key in config.js
3. Open index.html in browser

## API Used
OpenWeatherMap API

## Author
Your Name