const weatherService = new WeatherService();
const storage = new StorageManager();
const ui = new UI();

const cityInput = document.getElementById("cityInput");
const searchBtn = document.getElementById("searchBtn");
const toggleUnit = document.getElementById("toggleUnit");

async function fetchWeather(city) {

    try {

        document.getElementById("loading").classList.remove("hidden");

        const currentWeather =
            await weatherService.getCurrentWeather(city);

        const forecast =
            await weatherService.getForecast(city);

        ui.displayWeather(currentWeather);

        ui.displayForecast(forecast);

        storage.saveCity(city);

        document.getElementById("error").classList.add("hidden");

    } catch (error) {

        document.getElementById("error").innerText =
            error.message;

        document.getElementById("error")
            .classList.remove("hidden");

    } finally {

        document.getElementById("loading")
            .classList.add("hidden");
    }
}

searchBtn.addEventListener("click", () => {

    const city = cityInput.value;

    if (city.trim() !== "") {
        fetchWeather(city);
    }
});

toggleUnit.addEventListener("click", () => {

    ui.unit = ui.unit === "C" ? "F" : "C";

    toggleUnit.innerText =
        ui.unit === "C"
        ? "Switch to °F"
        : "Switch to °C";

    const savedCity = storage.getCity();

    if (savedCity) {
        fetchWeather(savedCity);
    }
});

window.addEventListener("load", () => {

    const savedCity = storage.getCity();

    if (savedCity) {
        fetchWeather(savedCity);
    }
});