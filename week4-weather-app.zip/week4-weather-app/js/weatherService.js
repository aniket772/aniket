class WeatherService {

    async getCurrentWeather(city) {

        const response = await fetch(
            `https://wttr.in/${city}?format=j1`
        );

        if (!response.ok) {
            throw new Error("City not found");
        }

        const data = await response.json();

        return {
            name: city,
            main: {
                temp: data.current_condition[0].temp_C,
                humidity: data.current_condition[0].humidity
            },
            weather: [{
                description:
                    data.current_condition[0]
                    .weatherDesc[0].value
            }],
            wind: {
                speed: data.current_condition[0].windspeedKmph
            },
            sys: {
                country: "IN"
            }
        };
    }

    async getForecast(city) {

        const response = await fetch(
            `https://wttr.in/${city}?format=j1`
        );

        const data = await response.json();

        return {
            list: data.weather.map(day => ({
                dt_txt: day.date,
                main: {
                    temp: day.avgtempC
                },
                weather: [{
                    description:
                        day.hourly[0].weatherDesc[0].value
                }]
            }))
        };
    }
}