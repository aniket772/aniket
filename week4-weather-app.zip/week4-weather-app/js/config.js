const CONFIG = {
    API_KEY: "...",
    BASE_URL: "..."
};