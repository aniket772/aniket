class UI {

    constructor() {
        this.currentWeather = document.getElementById("currentWeather");
        this.forecast = document.getElementById("forecast");

        this.unit = "C";
    }

    displayWeather(data) {

        let temp = data.main.temp;

        if (this.unit === "F") {
            temp = (temp * 9/5) + 32;
        }

        this.currentWeather.innerHTML = `
            <div class="weather-card">
                <h2>${data.name}, ${data.sys.country}</h2>

                <h1>${Math.round(temp)}°${this.unit}</h1>

                <p>${data.weather[0].description}</p>

                <p>Humidity: ${data.main.humidity}%</p>

                <p>Wind Speed: ${data.wind.speed} m/s</p>
            </div>
        `;
    }

    displayForecast(data) {

        let html = `<div class="forecast-container">`;

        data.list.slice(0, 5).forEach(item => {

            html += `
                <div class="forecast-card">

                    <h3>
                        ${new Date(item.dt_txt).toDateString()}
                    </h3>

                    <p>${Math.round(item.main.temp)}°</p>

                    <p>${item.weather[0].description}</p>

                </div>
            `;
        });

        html += `</div>`;

        this.forecast.innerHTML = html;
    }
}