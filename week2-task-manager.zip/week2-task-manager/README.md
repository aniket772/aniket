# Interactive Task Manager

## Project Description

Interactive Task Manager is a feature-rich task management web application built using HTML, CSS, and Vanilla JavaScript. The application allows users to manage daily tasks efficiently with features like task creation, editing, deletion, completion tracking, filtering, dark/light mode, drag-and-drop functionality, and localStorage data persistence.

The project demonstrates JavaScript DOM manipulation, event handling, local storage usage, array methods, and responsive UI design.

---

# Features

- Add new tasks
- Edit existing tasks
- Delete tasks
- Mark tasks as complete/incomplete
- Filter tasks (All, Active, Completed)
- Search tasks
- Due date support
- Priority levels (Low, Medium, High)
- Drag and drop task reordering
- Dark/Light mode toggle
- Task statistics display
- Data persistence using localStorage
- Responsive user interface

---

# Technologies Used

- HTML5
- CSS3
- JavaScript (Vanilla JS)
- LocalStorage API

---

# Project Objectives

The main objectives of this project are:

- Learn JavaScript fundamentals
- Practice DOM manipulation
- Implement event handling
- Understand localStorage
- Build responsive web interfaces
- Improve frontend development skills

---

# Setup and Installation

## Step 1: Download Project

Download or clone the repository.

```bash
git clone https://github.com/yourusername/your-repo.git