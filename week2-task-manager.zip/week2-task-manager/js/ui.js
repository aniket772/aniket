function renderTasks(tasks) {

    const taskList = document.getElementById("taskList");

    taskList.innerHTML = "";

    tasks.forEach(task => {

        const li = document.createElement("li");

        li.className = `task-item ${task.completed ? "completed" : ""} ${task.priority}`;

        li.setAttribute("draggable", true);

        li.innerHTML = `
            <div>
                <input type="checkbox" ${task.completed ? "checked" : ""}>

                <div>
                    <span class="task-text">${task.text}</span>
                    <small>${task.dueDate || "No Due Date"}</small>
                </div>
            </div>

            <div>
                <button class="edit-btn">Edit</button>
                <button class="delete-btn">Delete</button>
            </div>
        `;

        // Complete Task
        li.querySelector("input").addEventListener("change", () => {
            toggleTask(task.id);
        });

        // Delete Task
        li.querySelector(".delete-btn").addEventListener("click", () => {
            deleteTask(task.id);
        });

        // Edit Task
        li.querySelector(".edit-btn").addEventListener("click", () => {
            editTask(task.id);
        });

        // Drag Start
        li.addEventListener("dragstart", () => {
            li.classList.add("dragging");
        });

        // Drag End
        li.addEventListener("dragend", () => {
            li.classList.remove("dragging");
        });

        taskList.appendChild(li);
    });

    updateStats(tasks);
}

function updateStats(tasks) {

    const total = tasks.length;

    const completed = tasks.filter(task => task.completed).length;

    const active = total - completed;

    document.getElementById("totalTasks").textContent = total;

    document.getElementById("completedTasks").textContent = completed;

    document.getElementById("activeTasks").textContent = active;
}