function generateID() {
    return Date.now();
}