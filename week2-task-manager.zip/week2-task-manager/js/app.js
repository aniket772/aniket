let tasks = loadTasks();

let currentFilter = "all";

const taskForm = document.getElementById("taskForm");

const taskInput = document.getElementById("taskInput");

const priorityInput = document.getElementById("priority");


// Initial Render
filterTasks();


// Add Task
taskForm.addEventListener("submit", (e) => {

    e.preventDefault();

    const text = taskInput.value.trim();

    if(text === "") {
        alert("Task cannot be empty");
        return;
    }

    const task = {
    id: generateID(),
    text: text,
    completed: false,
    priority: priorityInput.value,
    dueDate: document.getElementById("dueDate").value
};

    tasks.push(task);

    saveTasks(tasks);

    filterTasks();

    taskForm.reset();
});


// Delete Task
function deleteTask(id) {

    tasks = tasks.filter(task => task.id !== id);

    saveTasks(tasks);

    filterTasks();
}


// Toggle Complete
function toggleTask(id) {

    tasks = tasks.map(task => {

        if(task.id === id) {
            task.completed = !task.completed;
        }

        return task;
    });

    saveTasks(tasks);

    filterTasks();
}


// Edit Task
function editTask(id) {

    const task = tasks.find(task => task.id === id);

    const newText = prompt("Edit task:", task.text);

    if(newText !== null && newText.trim() !== "") {

        task.text = newText;

        saveTasks(tasks);

        filterTasks();
    }
}


// Filter Tasks
function filterTasks() {

    let filtered = [];

    if(currentFilter === "active") {

        filtered = tasks.filter(task => !task.completed);

    } else if(currentFilter === "completed") {

        filtered = tasks.filter(task => task.completed);

    } else {

        filtered = tasks;
    }

    renderTasks(filtered);
}


// Filter Buttons
document.querySelectorAll(".filters button").forEach(button => {

    button.addEventListener("click", () => {

        currentFilter = button.dataset.filter;

        filterTasks();
    });
});


// Theme Toggle
const themeToggle = document.getElementById("themeToggle");

if(localStorage.getItem("theme") === "dark") {
    document.body.classList.add("dark-mode");
}

themeToggle.addEventListener("click", () => {

    document.body.classList.toggle("dark-mode");

    if(document.body.classList.contains("dark-mode")) {
        localStorage.setItem("theme", "dark");
    } else {
        localStorage.setItem("theme", "light");
    }
});


// Clear Completed
document.getElementById("clearCompleted").addEventListener("click", () => {

    tasks = tasks.filter(task => !task.completed);

    saveTasks(tasks);

    filterTasks();
});
document.getElementById("searchInput").addEventListener("input", (e) => {

    const value = e.target.value.toLowerCase();

    const filtered = tasks.filter(task =>
        task.text.toLowerCase().includes(value)
    );

    renderTasks(filtered);
});
document.addEventListener("keydown", (e) => {

    if(e.key === "Enter") {
        taskForm.requestSubmit();
    }
});